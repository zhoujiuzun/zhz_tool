
// Everything IPC test

// revision 2:
// fixed command line interpreting '-' as a switch inside text.

// revision 3:
// convert unicode to same code page as console.

// revision 4:
// removed write console because it has no support for piping.

// compiler options
#pragma warning(disable : 4311) // type cast void * to unsigned int
#pragma warning(disable : 4312) // type cast unsigned int to void *
#pragma warning(disable : 4244) // warning C4244: 'argument' : conversion from 'LONG_PTR' to 'LONG', possible loss of data
#pragma warning(disable : 4996) // deprecation

#include <windows.h>
#include <stdio.h>

#include "everything_ipc.h"

#define COPYDATA_IPCTEST_QUERYCOMPLETEW	0

int sort = 0;
EVERYTHING_IPC_LIST *sort_list;

// query everything with search string
int sendquery(HWND hwnd,DWORD num,WCHAR *search_string,int regex,int match_case,int match_whole_word,int match_path)
{
	EVERYTHING_IPC_QUERY *query;
	int len;
	int size;
	HWND everything_hwnd;
	COPYDATASTRUCT cds;
	
	everything_hwnd = FindWindow(EVERYTHING_IPC_WNDCLASS,0);
	if (everything_hwnd)
	{
		len = (int)wcslen(search_string);
		
		size = sizeof(EVERYTHING_IPC_QUERY) - sizeof(WCHAR) + len*sizeof(WCHAR) + sizeof(WCHAR);
		
		query = (EVERYTHING_IPC_QUERY *)HeapAlloc(GetProcessHeap(),0,size);
		if (query)
		{
			query->max_results = num;
			query->offset = 0;
			query->reply_copydata_message = COPYDATA_IPCTEST_QUERYCOMPLETEW;
			query->search_flags = (regex?EVERYTHING_IPC_REGEX:0) | (match_case?EVERYTHING_IPC_MATCHCASE:0) | (match_whole_word?EVERYTHING_IPC_MATCHWHOLEWORD:0) | (match_path?EVERYTHING_IPC_MATCHPATH:0);
			query->reply_hwnd = hwnd;
			CopyMemory(query->search_string,search_string,(len+1)*sizeof(WCHAR));
		
			cds.cbData = size;
			cds.dwData = EVERYTHING_IPC_COPYDATAQUERY;
			cds.lpData = query;

			if (SendMessage(everything_hwnd,WM_COPYDATA,(WPARAM)hwnd,(LPARAM)&cds) == TRUE)
			{
				HeapFree(GetProcessHeap(),0,query);
				
				return 1;
			}
			else
			{
				printf("Everything IPC service not running.\n");
			}

			HeapFree(GetProcessHeap(),0,query);
		}
		else
		{
			printf("failed to allocate %d bytes for IPC query.\n",size);
		}
	}
	else
	{
		// the everything window was not found.
		// we can optionally RegisterWindowMessage("EVERYTHING_IPC_CREATED") and 
		// wait for Everything to post this message to all top level windows when its up and running.
		printf("Everything IPC window not found, IPC unavailable.\n");
	}

	return 0;
}

int compare_list_items(const void *a,const void *b)
{
	int i;
	
	i = wcsicmp(EVERYTHING_IPC_ITEMPATH(sort_list,a),EVERYTHING_IPC_ITEMPATH(sort_list,b));
	
	if (!i)
	{
		return wcsicmp(EVERYTHING_IPC_ITEMFILENAME(sort_list,a),EVERYTHING_IPC_ITEMFILENAME(sort_list,b));
	}
	else
	if (i > 0)
	{
		return 1;
	}
	else
	{
		return -1;
	}
}

void write(char *p,int len)
{
	while(len)
	{
		printf("%c",*p);
		
		p++;
		len--;
	}
}

void listresultsW(EVERYTHING_IPC_LIST *list)
{
	DWORD i;
	UINT cp;
	char *mb;
	int len;

	cp = GetConsoleOutputCP();
	
//printf("using code page : %d\n",cp);	
	mb = HeapAlloc(GetProcessHeap(),0,65536);
	if (mb)
	{
		if (sort)
		{
			sort_list = list;
			qsort(list->items,list->numitems,sizeof(EVERYTHING_IPC_ITEM),compare_list_items);
		}
		
		for(i=0;i<list->numitems;i++)
		{
			if (list->items[i].flags & EVERYTHING_IPC_DRIVE)
			{
				len = WideCharToMultiByte(cp,0,EVERYTHING_IPC_ITEMFILENAME(list,&list->items[i]),(int)wcslen(EVERYTHING_IPC_ITEMFILENAME(list,&list->items[i])),mb,65536,0,0);
				write(mb,len);
				len = WideCharToMultiByte(cp,0,L"\n",1,mb,65536,0,0);
				write(mb,len);
			}
			else
			{
				len = WideCharToMultiByte(cp,0,EVERYTHING_IPC_ITEMPATH(list,&list->items[i]),(int)wcslen(EVERYTHING_IPC_ITEMPATH(list,&list->items[i])),mb,65536,0,0);
				write(mb,len);
				if ((len) && (mb[len-1] != '\\')) 
				{
					len = WideCharToMultiByte(cp,0,L"\\",1,mb,65536,0,0);
					write(mb,len);
				}
				len = WideCharToMultiByte(cp,0,EVERYTHING_IPC_ITEMFILENAME(list,&list->items[i]),(int)wcslen(EVERYTHING_IPC_ITEMFILENAME(list,&list->items[i])),mb,65536,0,0);
				write(mb,len);
				len = WideCharToMultiByte(cp,0,L"\n",1,mb,65536,0,0);
				write(mb,len);
			}
		}
		
		HeapFree(GetProcessHeap(),0,mb);
	}
	
	PostQuitMessage(0);
}

// custom window proc
LRESULT __stdcall window_proc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch(msg)
	{
		case WM_COPYDATA:
		{
			COPYDATASTRUCT *cds = (COPYDATASTRUCT *)lParam;
			
			switch(cds->dwData)
			{
				case COPYDATA_IPCTEST_QUERYCOMPLETEW:
					listresultsW((EVERYTHING_IPC_LIST *)cds->lpData);
					return TRUE;
			}
			
			break;
		}
	}
	
	return DefWindowProc(hwnd,msg,wParam,lParam);
}

void help(void)
{
//	printf("Everything Search\n");
	printf("-r Search the database using a basic POSIX regular expression.\n");
	printf("-i Does a case sensitive search.\n");
	printf("-w Does a whole word search.\n");
	printf("-p Does a full path search.\n");
	printf("-h --help Display this help.\n");
	printf("-n <num> Limit the amount of results shown to <num>.\n");
	printf("-s Sort by full path.\n");
}

// main entry
int main(int argc,char **argv)
{
	WNDCLASSEX wcex;
	HWND hwnd;
	MSG msg;
	int ret;
	int q;
	wchar_t *search;
	wchar_t *d;
	wchar_t *e;
	wchar_t *s;
	int match_whole_word = 0;
	int match_path = 0;
	int regex = 0;
	int match_case = 0;
	int wasexename = 0;
	int matchpath = 0;
	int i;
	int wargc;
	wchar_t **wargv;
	DWORD num = EVERYTHING_IPC_ALLRESULTS;
	
	ZeroMemory(&wcex,sizeof(wcex));
	wcex.cbSize = sizeof(wcex);
	
	if (!GetClassInfoEx(GetModuleHandle(0),TEXT("IPCTEST"),&wcex))
	{
		ZeroMemory(&wcex,sizeof(wcex));
		wcex.cbSize = sizeof(wcex);
		wcex.hInstance = GetModuleHandle(0);
		wcex.lpfnWndProc = window_proc;
		wcex.lpszClassName = TEXT("IPCTEST");
		
		if (!RegisterClassEx(&wcex))
		{
			printf("failed to register IPCTEST window class\n");
			
			return 1;
		}
	}
	
	if (!(hwnd = CreateWindow(
		TEXT("IPCTEST"),
		TEXT(""),
		0,
		0,0,0,0,
		0,0,GetModuleHandle(0),0)))
	{
		printf("failed to create IPCTEST window\n");
		
		return 1;
	}
	
	wargv = CommandLineToArgvW(GetCommandLineW(),&wargc);

/*
{
	wchar_t buf[256];
	
	WideCharToMultiByte(cp,0,GetCommandLine(),-1,buf,256,0,0);
	printf("%s\n",buf);
	return 1;
}
*/

	search = HeapAlloc(GetProcessHeap(),0,65536);
	if (!search)
	{
		printf("failed to allocate %d bytes for search buffer.\n",65536);
		
		return 1;
	}
	
	d = search;

	// allow room for null terminator
	e = search + (65536 / sizeof(wchar_t)) - 1;
	
	wargc--;
	i = 0;
	for(;;)
	{
		if (i >= wargc) break;
		
		if (wcsicmp(wargv[i+1],L"-r") == 0)
		{
			regex = 1;
		}
		else
		if (wcsicmp(wargv[i+1],L"-i") == 0)
		{
			match_case = 1;
		}
		else
		if (wcsicmp(wargv[i+1],L"-w") == 0)
		{
			match_whole_word = 1;
		}
		else
		if (wcsicmp(wargv[i+1],L"-p") == 0)
		{
			match_path = 1;
		}
		else
		if (wcsicmp(wargv[i+1],L"-s") == 0)
		{
			sort = 1;
		}
		else
		if ((wcsicmp(wargv[i+1],L"-n") == 0) && (i + 1 < wargc))
		{
			i++;
			
			num = _wtoi(wargv[i+1]);
		}
		else
		if (wargv[i+1][0] == '-')
		{
			// unknwon command
			help();
			HeapFree(GetProcessHeap(),0,search);
			return 1;
		}
		else
		{
			// keep quotes ?
			q = 0;
			
			s = wargv[i+1];
			while(*s)
			{
				if ((*s == ' ') || (*s == '\t') || (*s == '\r') || (*s == '\n'))
				{
					q = 1;
					break;	
				}
				
				s++;
			}
			
			if ((d != search) && (d < e)) *d++ = ' ';

			if (q)
			{
				if (d < e) *d++ = '"';
			}

			// copy append to search
			s = wargv[i+1];
			while(*s)
			{
				if (d < e) *d++ = *s;
				s++;
			}

			if (q)
			{
				if (d < e) *d++ = '"';
			}
		}
		
		i++;
	}
	
	// null terminate
	*d = 0;

	if (!sendquery(hwnd,num,search,regex,match_case,match_whole_word,match_path)) 
	{
		// send query reports error
		
		HeapFree(GetProcessHeap(),0,search);
		
		return 1;
	}

	HeapFree(GetProcessHeap(),0,search);

	// message pump
loop:

	WaitMessage();
	
	// update windows
	while(PeekMessage(&msg,NULL,0,0,0)) 
	{
		ret = (int)GetMessage(&msg,0,0,0);
		if (ret == -1) goto exit;
		if (!ret) goto exit;
		
		// let windows handle it.
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}			
	
	goto loop;

exit:
		
	return 0;
}
